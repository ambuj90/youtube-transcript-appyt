const express = require("express");
const cors = require("cors");
const axios = require("axios");

const app = express();
app.use(cors({
    origin: "*",  // Allow all origins
    methods: ["GET"]
}));
app.use(express.json());

// Your RapidAPI credentials
const RAPIDAPI_KEY = "edf1273786msh447b24e01dc3be7p10e389jsn0133ac6cf327";
const RAPIDAPI_HOST = "youtube-transcript3.p.rapidapi.com";

// Function to fetch transcript
const fetchTranscript = async (videoUrl) => {
    try {
        const encodedUrl = encodeURIComponent(videoUrl);
        const apiUrl = `https://${RAPIDAPI_HOST}/api/transcript-with-url?url=${encodedUrl}&flat_text=true&lang=en`;

        const options = {
            method: "GET",
            headers: {
                "x-rapidapi-key": RAPIDAPI_KEY,
                "x-rapidapi-host": RAPIDAPI_HOST
            }
        };

        const response = await axios.get(apiUrl, options);
        return response.data;
    } catch (error) {
        console.error("Error fetching transcript:", error.message);
        return null;
    }
};

// API Endpoint
app.get("/transcript", async (req, res) => {
    const { videoUrl } = req.query;

    if (!videoUrl) {
        return res.status(400).json({ error: "Video URL is required" });
    }

    const transcript = await fetchTranscript(videoUrl);

    if (!transcript) {
        return res.status(500).json({ error: "Could not fetch transcript. Please check the video URL or try again later." });
    }

    res.json({ transcript });
});

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
